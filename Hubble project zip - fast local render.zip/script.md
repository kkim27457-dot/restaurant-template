# Glasses for a Telescope — The Hubble Story
3d-story-shorts project #2. Picked by the user 2026-11-09 (idea 2 of the original 5).
Script: 12 shots, 179 spoken words (~60s at the Casper pace used for The Hidden Spire).

## Shot table
| # | key | line |
|---|-----|------|
| 1 | hook | In nineteen ninety, a one point five billion dollar telescope launched to photograph the universe. Its pictures came back blurry. |
| 2 | mirror | You see, its mirror was the most precisely polished ever made — and precisely the wrong shape. |
| 3 | public | By summer it was public: the telescope could not focus. It was a national punchline. |
| 4 | rim | The mirror stretched two point four meters across — its rim too flat by a fiftieth of a hair. |
| 5 | tester | The measuring machine had a lens one point three millimeters out of place. Every test passed. |
| 6 | orbit | But the mirror was already in orbit — far too large to bring home or swap. |
| 7 | glasses | You see, when your eyes are the wrong shape, nobody replaces your eyes. You get glasses. |
| 8 | build | So engineers built it glasses: five pairs of coin-sized mirrors on folding arms. |
| 9 | costar | They packed the mirrors into a phone-booth-sized box: COSTAR. |
| 10 | spacewalk | In December nineteen ninety-three, astronauts fitted them by hand — five spacewalks, thirty-five hours. |
| 11 | galaxy | On January thirteenth, nineteen ninety-four, NASA showed galaxy M100 twice: smudge — then perfect spiral. |
| 12 | twist | Hubble's mirror is still wrong today. It just sees the universe through glasses now. |

## Fact map (every claim double-sourced)
- **Launch April 24, 1990, Discovery (STS-31); $1.5B cost** — space.com Hubble servicing timeline; Astronomy Magazine, "Techno-turkey" (2020); also 19FortyFive + AmericaSpace.
- **Blurry first images; spherical aberration announced by NASA June 27, 1990** — space.com ("In June 1990, NASA announced…"); IPWatchdog (June 27 press conference); 19FortyFive (announced June 27, 1990).
- **Primary mirror 2.4 m (Perkin-Elmer); rim too flat by ~2.2 micrometres ≈ 1/50 of a human hair** — NASA via The Hindu (2.2 microns, 1/50 of hair); space.com (2-micron, 1/50 hair); SpaceDaily (2.2 micrometres, one-fiftieth).
- **Cause: reflective null corrector ("the measuring machine") assembled with a lens 1.3 mm out of position, so all its checks passed** — Hackaday, quoting NASA's Allen Report (laser reflected off a worn spot on a cap; corrector off by 1.3 mm → 2200 nm defect); SpaceDaily (chipped paint flake → 1.3 mm); bad.technology (one lens 1.3 mm out of position).
- **Public mockery / "national punchline"** — Astronomy Magazine (immediate public and political reaction); Medium ("became a punchline"); "techno turkey" label in Astronomy Magazine + AmericaSpace headlines.
- **Mirror could not be replaced on orbit** — Curio Infinity ("rather than replace the flawed mirror (impossible with existing shuttle capabilities), they would build a corrective optics device"); IPWatchdog (COSTAR developed instead of replacement).
- **COSTAR: five pairs of corrective mirrors, some coin-sized (nickel), on deployable arms; telephone-booth-sized box** — NASA science.nasa.gov SM1 page ("telephone booth-sized instrument that placed five pairs of corrective mirrors, some as small as a U.S. nickel coin, on deployable arms"); NASA "Two Hubbles" page (same wording); The Hindu (five pairs on deployable arms, coin-sized).
- **STS-61: Endeavour, Dec 2, 1993; five back-to-back spacewalks, 35 h 28 min** — NASA science.nasa.gov SM1 (five spacewalks, 35 h 28 min); Historic Spacecraft (record five spacewalks, over 35 hours); The Hindu (Dec 4–8, five spacewalks).
- **Jan 13, 1994: first corrected images released; M100 before/after** — ASP conference paper ("first new images… released on 13 January 1994", M100 before/after figure); IPWatchdog (Jan 13, 1994 M100 moment of truth); Sky & Telescope via FreeLibrary (Jan 13 press conference, M100 comparison).
- **Mirror never fixed; COSTAR removed in 2009 because later instruments carried the correction built in** — Pigeon Roost (WFPC2 and COSTAR removed in 2009); ASP paper (all later instruments designed with the correction). Twist close stays a fair metaphor: the primary mirror still has its aberration; every image since has been optically corrected.

## Left out (true, but cut for length/clarity)
- The chipped-paint-flake + washer detail behind the 1.3 mm error (superb, but needs 2 shots to land).
- The two cheaper backup testers DID report the flaw and were overruled (Allen Report) — villain-adjacent; the skill bans a real person/company as villain, so Perkin-Elmer is never named.
- The 70%-of-light specification vs ~15% actual performance.
- First corrected image actually seen Dec 18, 1993 at STScI; the script uses the public Jan 13, 1994 reveal.
- WFPC2 (the new camera with built-in correction, installed on the same mission): the script frames the whole fix as "glasses", NASA's own standard metaphor; shot 11 names no instrument.
- Mikulski's "the trouble with Hubble is over" quote — quotes stay out unless essential.
- COSTAR's shower-head inspiration anecdote (single-sourced colour).
