import * as THREE from 'three';
import {rng, toon, box, cyl, sign, crate, ground, sidewalk, facade, cloud, paintTex, ink} from './kit.js';
import {character} from './char.js';
import {wordT} from './camera.js';
import {dressStreet, dressPlaza, dressHall, dressLab, dressShop, dressScreen} from './dress.js';

export const LOC = {pad: 0, hall: 300, street: 600, lab: 900, orbit: 1200, shop: 1500, screen: 2100};

// smooth 0..1 between a and b (seconds)
export const ease = (t, a, b) => { const x = Math.min(1, Math.max(0, (t - a) / (b - a))); return x * x * (3 - 2 * x); };

function ctex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
}

// thin box stretched between two points (arms, braces, laser mounts)
function beamBetween(a, b, t, color) {
  const A = new THREE.Vector3(...a), B = new THREE.Vector3(...b);
  const len = A.distanceTo(B);
  const m = box(t, t, len, color, {thick: 0.012});
  m.position.copy(A).add(B).multiplyScalar(0.5);
  m.lookAt(B);
  return m;
}

function streetBase(ox, {lit = false, seed = 1} = {}) {
  const g = new THREE.Group();
  g.add(ground(260, 200, lit ? '#3b3a48' : '#9c958a', {x: ox, z: -30, seed: seed + 2, repeat: 20}));
  const road = new THREE.Mesh(new THREE.BoxGeometry(260, 0.05, 9), toon(lit ? '#34303e' : '#6e6670'));
  road.position.set(ox, 0.03, 12); g.add(road);
  for (let i = 0; i < 8; i++) g.add(box(0.7, 0.06, 7.6, '#efe7d2', {x: ox - 15.5 + (i % 4) * 1.1 + (i < 4 ? 0 : 31), y: 0.07, z: 12, edges: false, thick: 0.001}));
  for (let i = -12; i < 12; i++) g.add(box(3, 0.06, 0.35, '#e8d28a', {x: ox + i * 10, y: 0.08, z: 12, edges: false, thick: 0.001}));
  g.add(sidewalk(260, {x: ox, z: 5.5, w: 4}));
  g.add(sidewalk(260, {x: ox, z: 18.5, w: 4}));
  const cols = ['#c98f6b', '#b8775e', '#d1a47a', '#a86f5c', '#c4a27c', '#9e7b66'];
  const r = rng(seed);
  for (let i = 0; i < 7; i++) {
    for (const side of [-1, 1]) {
      const w = 9 + r() * 3, h = 9 + r() * 10;
      const f = facade({w, h, color: cols[(i + (side > 0 ? 2 : 0)) % cols.length], cols: 3, rows: Math.floor(h / 3.6), seed: seed + i * 7 + side, lit, interior: lit ? '#ffcf7d' : '#3b2b33'});
      f.position.set(ox + side * (18 + i * 12.5), 0, 3);
      g.add(f);
      g.add(box(w, h, 8, '#8f6c5e', {x: ox + side * (18 + i * 12.5), y: h / 2, z: -1.4, thick: 0.04}));
    }
  }
  for (let i = -6; i < 7; i++) {
    const w = 10 + r() * 3, h = 8 + r() * 9;
    const f = facade({w, h, color: cols[(i + 9) % cols.length], cols: 3, rows: Math.floor(h / 3.6), seed: seed + 100 + i, lit, interior: lit ? '#ffcf7d' : '#3b2b33'});
    f.position.set(ox + i * 13, 0, 22); f.rotation.y = Math.PI; g.add(f);
    g.add(box(w, h, 8, '#8f6c5e', {x: ox + i * 13, y: h / 2, z: 26.4, thick: 0.04}));
  }
  for (let i = 0; i < 14; i++) {
    const h = 25 + r() * 45, w = 10 + r() * 10;
    g.add(box(w, h, 10, lit ? '#3a3658' : '#b9c3c9', {x: ox - 90 + i * 14 + r() * 4, y: h / 2, z: -80 - r() * 30, thick: 0.08}));
  }
  return g;
}

function room(ox, {w = 14, h = 5, d = 10, wall = '#efe0c4', floor = '#a7764e', seed = 4} = {}) {
  const g = new THREE.Group();
  const wt = paintTex(wall, {seed, stains: 14}); wt.repeat.set(2, 1);
  const walls = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), toon('#ffffff', wt, {side: THREE.BackSide}));
  walls.position.set(ox, h / 2, 0); walls.receiveShadow = true; g.add(walls);
  const ft = paintTex(floor, {seed: seed + 1, stripes: (gg, W, H) => { gg.strokeStyle = 'rgba(60,30,15,0.35)'; gg.lineWidth = 2; for (let i = 0; i < 10; i++) { gg.beginPath(); gg.moveTo(0, i * H / 10); gg.lineTo(W, i * H / 10); gg.stroke(); } }});
  ft.repeat.set(3, 2);
  const fl = new THREE.Mesh(new THREE.BoxGeometry(w - 0.02, 0.1, d - 0.02), toon('#ffffff', ft)); fl.position.set(ox, 0.0, 0); fl.receiveShadow = true; g.add(fl);
  g.add(box(w, 0.25, 0.15, '#6b4a36', {x: ox, y: 0.12, z: -d / 2 + 0.1, thick: 0.01}));
  return g;
}

// ---------- the shuttle stack on the pad (orbiter + orange tank + boosters) ----------
function makeShuttleStack() {
  const g = new THREE.Group();
  const tank = cyl(1.05, 1.05, 8.6, '#d97c2e', {y: 6.4, z: -1.35, seg: 18}); g.add(tank);
  g.add(cyl(0.08, 1.05, 1.8, '#d97c2e', {y: 11.6, z: -1.35, seg: 18}));
  const orb = new THREE.Group();
  orb.add(cyl(0.88, 0.98, 6.4, '#e8e6df', {y: 5.4, seg: 18}));
  orb.add(cyl(0.06, 0.88, 2.1, '#e8e6df', {y: 9.6, seg: 18}));
  orb.add(box(3.6, 0.16, 1.6, '#d8d4c9', {y: 2.5, thick: 0.03}));
  orb.add(box(0.2, 1.7, 1.2, '#3a3f45', {y: 3.3, z: -0.75, thick: 0.02}));
  orb.add(box(1.5, 0.7, 0.9, '#3a3f45', {y: 2.2, z: 0.2, thick: 0.02}));
  orb.position.z = 0.45; g.add(orb);
  for (const sx of [-1.6, 1.6]) {
    g.add(cyl(0.55, 0.62, 7.9, '#f0ede6', {x: sx, y: 5.2, z: -0.55, seg: 14}));
    g.add(cyl(0.05, 0.55, 1.4, '#f0ede6', {x: sx, y: 9.8, z: -0.55, seg: 14}));
  }
  // engine flame (shown during the climb)
  const flameMat = new THREE.MeshBasicMaterial({color: '#ff9a3c', transparent: true, opacity: 0.92, fog: false});
  const flame = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.06, 3.4, 12), flameMat);
  flame.position.set(0, -1.4, 0); g.add(flame); g.userData.flame = flame;
  return g;
}

// ---------- the Hubble telescope ----------
function makeHubble() {
  const g = new THREE.Group();
  const cellTex = paintTex('#2f5d9e', {seed: 61, stains: 2, chips: 2, scratches: 0, stripes: (gg, W, H) => { gg.strokeStyle = 'rgba(220,235,255,0.5)'; gg.lineWidth = 2; for (let i = 0; i < 6; i++) { gg.beginPath(); gg.moveTo(i * W / 6, 0); gg.lineTo(i * W / 6, H); gg.stroke(); } for (let i = 0; i < 3; i++) { gg.beginPath(); gg.moveTo(0, i * H / 3); gg.lineTo(W, i * H / 3); gg.stroke(); } }});
  const tube = cyl(1.05, 1.15, 7, '#cfd6dd', {seg: 20}); tube.rotation.x = Math.PI / 2; g.add(tube);
  const foil = cyl(1.16, 1.16, 2.2, '#d9a441', {seg: 20}); foil.rotation.x = Math.PI / 2; foil.position.z = -1.6; g.add(foil);
  const aft = cyl(1.25, 1.25, 1.6, '#9aa7b1', {seg: 20}); aft.rotation.x = Math.PI / 2; aft.position.z = -3.9; g.add(aft);
  g.add(box(1.7, 1.7, 1.2, '#7d8a8f', {z: -5.2, thick: 0.03}));
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.06, 0.08, 10, 28), toon('#8d979f')); ring.position.z = 3.5; ink(ring, 0.015, false); g.add(ring);
  const door = new THREE.Mesh(new THREE.CircleGeometry(0.98, 24), toon('#aeb9c2')); door.position.set(1.05, 0.35, 3.62); door.rotation.y = 0.85; g.add(door);
  const dark = new THREE.Mesh(new THREE.CircleGeometry(0.95, 24), new THREE.MeshBasicMaterial({color: '#232c36'})); dark.position.z = 3.48; g.add(dark);
  for (const sx of [-1, 1]) {
    const wing = new THREE.Group();
    const panel = new THREE.Mesh(new THREE.BoxGeometry(3.8, 1.6, 0.07), toon('#ffffff', cellTex)); ink(panel, 0.02, true); wing.add(panel);
    wing.add(box(0.5, 0.18, 0.18, '#8d979f', {x: -sx * 2.05, thick: 0.01}));
    wing.position.set(sx * 3.1, 0, -0.6); wing.rotation.z = sx * 0.1; g.add(wing);
  }
  const dish = new THREE.Mesh(new THREE.SphereGeometry(0.6, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), toon('#e8edf1'));
  dish.position.set(0.85, 1.45, -2.4); dish.rotation.x = -0.7; ink(dish, 0.015, false); g.add(dish);
  g.add(cyl(0.04, 0.04, 0.9, '#8d979f', {x: 0.85, y: 1.0, z: -2.4, seg: 6, thick: 0.005}));
  for (const sx of [-0.5, 0.5]) g.add(box(0.08, 0.08, 2.6, '#c9a227', {x: sx, y: -1.18, z: 0.6, thick: 0.006}));
  return g;
}

// ---------- a pair of glasses with crisp stars in the lenses ----------
function sharpStarTex() {
  return ctex(256, 256, (g, W, H) => {
    g.clearRect(0, 0, W, H);
    const r = rng(97);
    g.fillStyle = '#ffffff';
    for (let i = 0; i < 110; i++) { const s = 0.6 + r() * 1.6; g.globalAlpha = 0.35 + r() * 0.65; g.beginPath(); g.arc(r() * W, r() * H, s, 0, 7); g.fill(); }
    g.globalAlpha = 1;
    for (const [x, y] of [[128, 118], [70, 60], [190, 180]]) {
      g.strokeStyle = '#ffffff'; g.lineWidth = 3;
      g.beginPath(); g.moveTo(x - 16, y); g.lineTo(x + 16, y); g.moveTo(x, y - 16); g.lineTo(x, y + 16); g.stroke();
      const gr = g.createRadialGradient(x, y, 0, x, y, 15); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = gr; g.beginPath(); g.arc(x, y, 15, 0, 7); g.fill();
    }
  });
}
function makeGlasses(lensTex) {
  const g = new THREE.Group();
  for (const sx of [-0.87, 0.87]) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.78, 0.06, 10, 32), toon('#2b2b2e'));
    ring.position.set(sx, 0, 0); ink(ring, 0.012, false); g.add(ring);
    const lens = new THREE.Mesh(new THREE.CircleGeometry(0.74, 28), new THREE.MeshBasicMaterial({map: lensTex, transparent: true, depthWrite: false, fog: false}));
    lens.position.set(sx, 0, 0.01); g.add(lens);
    const temple = box(0.07, 0.07, 1.7, '#2b2b2e', {x: sx + Math.sign(sx) * 0.8, y: 0.18, z: -0.85, thick: 0.008}); g.add(temple);
  }
  g.add(box(0.55, 0.09, 0.07, '#2b2b2e', {y: 0.14, thick: 0.008}));
  return g;
}

// ---------- a simple 3D astronaut in a white suit ----------
function makeAstronaut() {
  const g = new THREE.Group();
  const suit = '#f2f0e9';
  g.add(cyl(0.34, 0.42, 0.95, suit, {y: 0.98, seg: 14}));
  g.add(box(0.56, 0.78, 0.3, '#dcd8ce', {y: 1.08, z: -0.34, thick: 0.02}));
  g.add(box(0.42, 0.32, 0.16, '#e3ded2', {y: 1.05, z: 0.3, thick: 0.015}));
  g.add(box(0.09, 0.09, 0.03, '#c43d32', {x: -0.1, y: 1.12, z: 0.39, thick: 0.004}), box(0.09, 0.09, 0.03, '#2f6db3', {x: 0.1, y: 1.12, z: 0.39, thick: 0.004}));
  const helm = new THREE.Mesh(new THREE.SphereGeometry(0.31, 16, 12), toon(suit)); helm.position.y = 1.76; ink(helm, 0.02, false); g.add(helm);
  const visor = new THREE.Mesh(new THREE.SphereGeometry(0.27, 16, 12), new THREE.MeshBasicMaterial({color: '#e8a33d', fog: false}));
  visor.position.set(0, 1.76, 0.07); visor.scale.set(0.92, 0.82, 0.62); g.add(visor);
  for (const sx of [-0.18, 0.18]) g.add(cyl(0.13, 0.15, 0.72, suit, {x: sx, y: 0.36, seg: 10}));
  for (const sx of [-0.2, 0.2]) g.add(box(0.2, 0.1, 0.34, '#c9c3b4', {x: sx, y: 0.03, z: 0.05, thick: 0.01}));
  const armL = cyl(0.1, 0.11, 0.64, suit, {seg: 10}); armL.position.set(-0.48, 1.05, 0.05); armL.rotation.z = 0.5; g.add(armL);
  const armR = cyl(0.1, 0.11, 0.64, suit, {seg: 10}); armR.position.set(0.5, 1.2, 0.3); armR.rotation.x = -1.05; armR.rotation.z = -0.25; g.add(armR);
  return g;
}

export function buildWorld() {
  const W = new THREE.Group();
  const chars = [];

  // ======== LAUNCH PAD AT DAWN (hook) ========
  const PD = LOC.pad;
  W.add(ground(220, 170, '#9c8f7a', {x: PD, z: -25, seed: 3, repeat: 14}));
  W.add(box(48, 0.3, 42, '#b5aa97', {x: PD, y: 0.15, z: -6, thick: 0.03}));
  W.add(box(11, 1.2, 11, '#8a8f93', {x: PD, y: 0.6, z: -8, thick: 0.04}));
  // gantry tower
  const gantry = new THREE.Group();
  for (const [gx, gz] of [[-0.95, -0.95], [0.95, -0.95], [-0.95, 0.95], [0.95, 0.95]]) gantry.add(box(0.28, 27, 0.28, '#a8542f', {x: gx, y: 13.5, z: gz, thick: 0.02}));
  for (let i = 0; i < 6; i++) { const y = 2.4 + i * 4.4; gantry.add(box(2.2, 0.22, 0.22, '#a8542f', {y, z: -0.95, thick: 0.012}), box(2.2, 0.22, 0.22, '#a8542f', {y, z: 0.95, thick: 0.012}), box(0.22, 0.22, 2.2, '#a8542f', {x: -0.95, y, thick: 0.012}), box(0.22, 0.22, 2.2, '#a8542f', {x: 0.95, y, thick: 0.012})); }
  gantry.add(box(2.4, 2.6, 2.4, '#e8e2d2', {y: 25.4, thick: 0.03}));
  gantry.add(box(5.4, 0.35, 0.35, '#a8542f', {x: 2.2, y: 23.8, z: 0, thick: 0.02}));
  gantry.position.set(PD - 4.8, 0.3, -8); W.add(gantry);
  for (const mx of [-11, 12]) W.add(cyl(0.07, 0.09, 31, '#6a7076', {x: PD + mx, y: 15.5, z: -8, seg: 6, thick: 0.008}));
  W.add(box(7, 3.2, 4, '#7d8a8f', {x: PD - 14, y: 1.6, z: 2, thick: 0.04}), box(5, 2.4, 3.4, '#97a3ab', {x: PD + 16, y: 1.2, z: 4, thick: 0.04}));
  const shuttle = makeShuttleStack(); shuttle.position.set(PD + 0.8, 1.2, -8); W.add(shuttle);
  // launch smoke puffs
  const smokeMat = new THREE.MeshBasicMaterial({color: '#efe9dc', transparent: true, opacity: 0});
  const smokes = [];
  const sr = rng(15);
  for (let i = 0; i < 11; i++) {
    const s = new THREE.Mesh(new THREE.SphereGeometry(1.1 + sr() * 0.9, 10, 8), smokeMat);
    const a = sr() * Math.PI * 2, d = 2.2 + sr() * 3.4;
    s.position.set(PD + 0.8 + Math.cos(a) * d, 0.7, -8 + Math.sin(a) * d);
    s.userData.dir = [Math.cos(a), Math.sin(a)]; W.add(s); smokes.push(s);
  }
  // photo screen: the first picture, sharp star then a blurry bloom
  const starSharpTex = ctex(512, 340, (g, w, h) => {
    g.fillStyle = '#0d1b33'; g.fillRect(0, 0, w, h);
    const r = rng(23); g.fillStyle = '#cfe0f4';
    for (let i = 0; i < 130; i++) { g.globalAlpha = 0.3 + r() * 0.7; g.beginPath(); g.arc(r() * w, r() * h, 0.6 + r() * 1.3, 0, 7); g.fill(); }
    g.globalAlpha = 1; g.fillStyle = '#ffffff';
    g.beginPath(); g.arc(256, 170, 3.2, 0, 7); g.fill();
    g.strokeStyle = '#ffffff'; g.lineWidth = 2.4;
    g.beginPath(); g.moveTo(232, 170); g.lineTo(280, 170); g.moveTo(256, 146); g.lineTo(256, 194); g.stroke();
  });
  const starBlurTex = ctex(512, 340, (g, w, h) => {
    g.clearRect(0, 0, w, h);
    const blob = (x, y, rad, col) => { const gr = g.createRadialGradient(x, y, 0, x, y, rad); gr.addColorStop(0, col); gr.addColorStop(1, 'rgba(160,190,235,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, rad, 0, 7); g.fill(); };
    blob(256, 170, 130, 'rgba(225,238,255,0.95)');
    blob(256, 170, 62, 'rgba(255,255,255,0.9)');
    blob(140, 100, 26, 'rgba(190,215,245,0.5)'); blob(390, 240, 30, 'rgba(190,215,245,0.45)'); blob(420, 90, 20, 'rgba(190,215,245,0.4)');
  });
  const screenG = new THREE.Group();
  screenG.add(box(6.8, 4.8, 0.25, '#3a3f45', {y: 3.6, thick: 0.03}));
  const scrBase = new THREE.Mesh(new THREE.PlaneGeometry(6.1, 4.1), new THREE.MeshBasicMaterial({map: starSharpTex, fog: false}));
  scrBase.position.set(0, 3.6, 0.16); screenG.add(scrBase);
  const scrBlurMat = new THREE.MeshBasicMaterial({map: starBlurTex, transparent: true, opacity: 0, fog: false});
  const scrBlur = new THREE.Mesh(new THREE.PlaneGeometry(6.1, 4.1), scrBlurMat);
  scrBlur.position.set(0, 3.6, 0.22); screenG.add(scrBlur);
  for (const px of [-2.6, 2.6]) screenG.add(cyl(0.09, 0.11, 1.6, '#3a3f45', {x: px, y: 0.8, seg: 8, thick: 0.01}));
  screenG.position.set(PD + 10.5, 0.3, -2); screenG.rotation.y = -0.35; W.add(screenG);
  const pw1 = character({palette: 'welder', hat: 'cap', seed: 111}); pw1.position.set(PD + 6.6, 0.3, -0.6); W.add(pw1); chars.push(pw1);
  const pw2 = character({palette: 'navy', hat: 'cap', seed: 112}); pw2.position.set(PD + 8.3, 0.3, 1.4); W.add(pw2); chars.push(pw2);
  for (let i = 0; i < 5; i++) W.add(cloud(PD - 80 + i * 42, 78 + (i % 3) * 10, -140, 6, '#f2e4d8'));

  // ======== MIRROR HALL (mirror + rim) ========
  const H = LOC.hall;
  W.add(room(H, {w: 20, h: 8, d: 14, wall: '#dfe9ec', floor: '#9a8a74', seed: 31}));
  const drawRefl = (warp) => ctex(512, 512, (g, w, h) => {
    const grad = g.createRadialGradient(256, 256, 30, 256, 256, 256);
    grad.addColorStop(0, '#eef6fb'); grad.addColorStop(0.55, '#c3d6e4'); grad.addColorStop(1, '#9db8cc');
    g.fillStyle = grad; g.fillRect(0, 0, w, h);
    g.strokeStyle = 'rgba(90,115,135,0.35)'; g.lineWidth = 2;
    for (let i = 1; i < 5; i++) { g.beginPath(); g.arc(256, 256, i * 52, 0, 7); g.stroke(); }
    // a reflected window grid: straight when correct, wavy when warped
    g.strokeStyle = 'rgba(52,74,96,0.75)'; g.lineWidth = 7;
    for (let i = 0; i < 4; i++) {
      const x0 = 96 + i * 106;
      g.beginPath();
      for (let y = 70; y <= 442; y += 12) { const x = x0 + Math.sin(y * 0.05 + i) * warp; if (y === 70) g.moveTo(x, y); else g.lineTo(x, y); }
      g.stroke();
    }
    for (let i = 0; i < 3; i++) {
      const y0 = 120 + i * 130;
      g.beginPath();
      for (let x = 60; x <= 452; x += 12) { const y = y0 + Math.sin(x * 0.05 + i * 2) * warp; if (x === 60) g.moveTo(x, y); else g.lineTo(x, y); }
      g.stroke();
    }
    const sheen = g.createLinearGradient(60, 0, 300, 0); sheen.addColorStop(0, 'rgba(255,255,255,0)'); sheen.addColorStop(0.5, 'rgba(255,255,255,0.35)'); sheen.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = sheen; g.save(); g.translate(256, 256); g.rotate(0.6); g.fillRect(-260, -260, 240, 520); g.restore();
  });
  const reflGood = drawRefl(1.5), reflWrong = drawRefl(13);
  const mirrorSide = toon('#8fa3ad');
  const discTopMat = toon('#ffffff', reflGood);
  const disc = new THREE.Mesh(new THREE.CylinderGeometry(3.4, 3.4, 0.5, 40), [mirrorSide, discTopMat, mirrorSide]);
  disc.position.set(H, 0.95, -1.5); ink(disc, 0.04, true, 50); W.add(disc);
  W.add(box(5.6, 0.55, 5.6, '#5f7a86', {x: H, y: 0.28, z: -1.5, thick: 0.04}));
  const trim = new THREE.Mesh(new THREE.TorusGeometry(3.42, 0.09, 10, 44), toon('#c9a227'));
  trim.rotation.x = Math.PI / 2; trim.position.set(H, 1.18, -1.5); ink(trim, 0.012, false); W.add(trim);
  // light sweep strip gliding over the surface
  const sweepMat = new THREE.MeshBasicMaterial({color: '#ffffff', transparent: true, opacity: 0.26, depthWrite: false});
  const sweep = new THREE.Mesh(new THREE.PlaneGeometry(7.6, 1.15), sweepMat);
  sweep.rotation.set(-Math.PI / 2, 0, 0.45); sweep.position.set(H - 3, 1.27, -1.5); W.add(sweep);
  // diameter beam + sign
  for (const px of [-3.4, 3.4]) W.add(cyl(0.07, 0.09, 5.4, '#44586b', {x: H + px, y: 2.7, z: -1.5, seg: 8, thick: 0.01}));
  W.add(box(8.8, 0.35, 0.35, '#44586b', {x: H, y: 5.35, z: -1.5, thick: 0.02}));
  const mSign = sign('2.4 METERS', 4.6, 1.05, {bg: '#f2e6cc', w: 900, h: 200, font: 'bold 108px Arial, sans-serif'});
  mSign.position.set(H, 4.5, -1.42); W.add(mSign);
  // straightedge across the rim + the red sliver of light under it (the flaw made visible)
  const edge = box(2.7, 0.09, 0.32, '#6a7076', {x: H + 2.2, y: 1.33, z: -1.0, thick: 0.012, ry: 0.4}); W.add(edge);
  const gapMat = new THREE.MeshBasicMaterial({color: '#ff4444', transparent: true, opacity: 0});
  const gap = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.025, 0.12), gapMat);
  gap.position.set(H + 2.2, 1.26, -1.0); gap.rotation.y = 0.4; W.add(gap);
  // a single hair lying by the rim
  const hair = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.03, 6, 24, Math.PI * 0.85), toon('#3a2a1c'));
  hair.rotation.set(-Math.PI / 2, 0, 0.7); hair.position.set(H + 2.85, 1.22, -1.0); ink(hair, 0.004, false); W.add(hair);
  dressHall(W, H, chars);
  const techA = character({palette: 'engineer', hat: 'bowler', glasses: true, seed: 1401}); techA.position.set(H + 1.9, 0.05, 2.1); W.add(techA); chars.push(techA);
  const techB = character({palette: 'student', hat: 'cap', seed: 1402}); techB.position.set(H - 2.6, 0.05, -4.4); W.add(techB); chars.push(techB);

  // ======== 1990 STREET + NEWSSTAND (public) ========
  const ST = LOC.street;
  W.add(streetBase(ST, {seed: 23}));
  const paperTex = ctex(256, 340, (g, w, h) => {
    g.fillStyle = '#f7f2e2'; g.fillRect(0, 0, w, h);
    g.fillStyle = '#45403a'; g.fillRect(24, 22, w - 48, 34);
    g.fillStyle = '#8a8378'; g.fillRect(24, 74, 96, 84);
    g.fillStyle = '#b6ae9e';
    for (let i = 0; i < 12; i++) g.fillRect(132, 74 + i * 12, w - 156, 5);
    for (let i = 0; i < 10; i++) g.fillRect(24, 178 + i * 13, w - 48, 5);
  });
  const paperMat = toon('#ffffff', paperTex);
  const stand = new THREE.Group();
  stand.add(box(4.2, 2.2, 1.8, '#2f5d62', {y: 1.35}));
  const awn = box(4.8, 0.16, 2.4, '#c43d32', {y: 2.62}); awn.rotation.x = 0.1; stand.add(awn);
  stand.add(box(4.2, 0.5, 0.5, '#8a5a3b', {y: 0.85, z: 0.95}));
  for (let i = 0; i < 4; i++) stand.add(box(0.72, 0.1 + i * 0.025, 0.52, '#f7f0de', {x: -1.3 + i * 0.85, y: 1.14, z: 0.98, thick: 0.008, ry: i * 0.25 - 0.3}));
  const bigPaper = new THREE.Mesh(new THREE.BoxGeometry(1.5, 1.05, 0.03), paperMat);
  bigPaper.position.set(0.4, 1.7, 1.02); bigPaper.rotation.x = -0.08; ink(bigPaper, 0.008, false); stand.add(bigPaper);
  stand.position.set(ST + 3.5, 0.25, 5.0); W.add(stand);
  const traffic = dressStreet(W, ST, {seed: 23, chars, avoid: [ST - 1, ST + 3.5]});
  dressPlaza(W, ST, chars);
  const reader1 = character({palette: 'clerk', hat: 'bowler', seed: 1501}); reader1.position.set(ST + 1.2, 0.25, 6.9); W.add(reader1); chars.push(reader1);
  const held1 = new THREE.Mesh(new THREE.BoxGeometry(0.88, 0.62, 0.02), paperMat); held1.position.set(0.3, 1.02, 0.2); held1.rotation.x = -0.15; reader1.add(held1);
  const reader2 = character({palette: 'student', hat: 'none', seed: 1502}); reader2.position.set(ST + 2.7, 0.25, 7.25); W.add(reader2); chars.push(reader2);
  const held2 = new THREE.Mesh(new THREE.BoxGeometry(0.88, 0.62, 0.02), paperMat); held2.position.set(-0.28, 1.02, 0.2); held2.rotation.x = -0.15; reader2.add(held2);
  const laugher = character({palette: 'red', hat: 'cap', seed: 1503}); laugher.position.set(ST + 1.85, 0.25, 7.55); W.add(laugher); chars.push(laugher);
  const clerkS = character({palette: 'official', hat: 'cap', seed: 1504}); clerkS.position.set(ST + 5.4, 0.25, 4.1); W.add(clerkS); chars.push(clerkS);
  for (let i = 0; i < 6; i++) W.add(cloud(ST - 100 + i * 40, 105 + (i % 3) * 9, -150, 6));

  // ======== TEST LAB (tester) ========
  const L = LOC.lab;
  W.add(room(L, {w: 16, h: 6, d: 12, wall: '#3d5a66', floor: '#4a4238', seed: 37}));
  // the mirror under test, facing the machine
  W.add(box(0.45, 1.15, 0.45, '#5a6a72', {x: L - 3.2, y: 0.58, z: -1.5, thick: 0.02}));
  const testDisc = cyl(1.5, 1.5, 0.18, '#8fa3ad', {x: L - 3.2, y: 1.95, z: -1.5, seg: 30, thick: 0.03}); testDisc.rotation.z = Math.PI / 2; W.add(testDisc);
  const testFace = new THREE.Mesh(new THREE.CircleGeometry(1.34, 30), new THREE.MeshBasicMaterial({color: '#cfe3f0'}));
  testFace.position.set(L - 3.08, 1.95, -1.5); testFace.rotation.y = Math.PI / 2; W.add(testFace);
  // the measuring machine
  const mach = new THREE.Group();
  mach.add(box(1.75, 0.3, 1.75, '#39434b', {y: 0.15}));
  mach.add(box(1.3, 2.6, 1.3, '#6a7d8a', {y: 1.6}));
  mach.add(box(0.95, 0.55, 0.95, '#54646f', {y: 3.15}));
  mach.add(box(0.98, 0.98, 0.07, '#2c343c', {y: 2.25, z: 0.68, thick: 0.012}));
  mach.position.set(L + 2.8, 0, -1.5); W.add(mach);
  // the green check light on the machine's face (appears on "passed")
  const checkG = new THREE.Group();
  const checkMat = new THREE.MeshBasicMaterial({color: '#37e08b', fog: false});
  const ringC = new THREE.Mesh(new THREE.TorusGeometry(0.31, 0.05, 8, 24), checkMat); checkG.add(ringC);
  const c1 = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.1, 0.04), checkMat); c1.position.set(-0.08, -0.03, 0.01); c1.rotation.z = -0.6; checkG.add(c1);
  const c2 = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.1, 0.04), checkMat); c2.position.set(0.13, 0.05, 0.01); c2.rotation.z = 0.72; checkG.add(c2);
  checkG.position.set(L + 2.8, 2.25, -0.78); checkG.visible = false; W.add(checkG);
  // the lens assembly + laser (the whole group sits 1.3 mm out — it slides visibly at the reveal)
  const lensG = new THREE.Group();
  const housing = cyl(0.34, 0.38, 0.55, '#3a3f45', {seg: 16, thick: 0.02}); housing.rotation.z = Math.PI / 2; lensG.add(housing);
  const lensFace = new THREE.Mesh(new THREE.CircleGeometry(0.26, 20), new THREE.MeshBasicMaterial({color: '#9fd8ff', fog: false}));
  lensFace.position.x = -0.29; lensFace.rotation.y = -Math.PI / 2; lensG.add(lensFace);
  const laserMat = new THREE.MeshBasicMaterial({color: '#ff3b30', transparent: true, opacity: 0.85, fog: false});
  const laser = new THREE.Mesh(new THREE.BoxGeometry(4.35, 0.035, 0.035), laserMat);
  laser.position.x = -2.45; lensG.add(laser);
  lensG.position.set(L + 2.05, 1.95, -1.5); W.add(lensG);
  W.add(box(0.3, 1.6, 0.3, '#39434b', {x: L + 2.05, y: 0.8, z: -1.5, thick: 0.02}));
  dressLab(W, L, chars);
  const oper = character({palette: 'engineer', hat: 'none', glasses: true, seed: 1601}); oper.position.set(L + 4.3, 0.05, -3.3); W.add(oper); chars.push(oper);

  // ======== ORBIT (orbit + glasses + spacewalk + twist) ========
  const OB = LOC.orbit;
  const hubble = makeHubble(); hubble.position.set(OB, 2.5, -7); hubble.rotation.y = 0.5; hubble.rotation.z = 0.06; W.add(hubble);
  const earthTex = ctex(512, 256, (g, w, h) => {
    g.fillStyle = '#2f6db3'; g.fillRect(0, 0, w, h);
    const r = rng(71);
    g.fillStyle = '#4f9e57';
    for (let i = 0; i < 16; i++) { g.beginPath(); g.ellipse(r() * w, r() * h, 18 + r() * 42, 10 + r() * 20, r() * 3, 0, 7); g.fill(); }
    g.fillStyle = '#c9a86a';
    for (let i = 0; i < 7; i++) { g.beginPath(); g.ellipse(r() * w, r() * h, 10 + r() * 18, 6 + r() * 10, r() * 3, 0, 7); g.fill(); }
    g.strokeStyle = 'rgba(255,255,255,0.75)'; g.lineWidth = 5; g.lineCap = 'round';
    for (let i = 0; i < 22; i++) { const y = r() * h; g.beginPath(); g.moveTo(r() * w, y); g.bezierCurveTo(r() * w, y - 14, r() * w, y + 14, r() * w * 0.4 + 90, y + (r() - 0.5) * 22); g.stroke(); }
    g.fillStyle = 'rgba(255,255,255,0.9)';
    g.fillRect(0, 0, w, 12); g.fillRect(0, h - 14, w, 14);
  });
  const earth = new THREE.Mesh(new THREE.SphereGeometry(55, 28, 20), new THREE.MeshBasicMaterial({map: earthTex, fog: false}));
  earth.position.set(OB - 18, -60, -78); W.add(earth);
  // star field
  const starGeo = new THREE.BufferGeometry();
  {
    const N = 520, pos = new Float32Array(N * 3), r = rng(83);
    for (let i = 0; i < N; i++) {
      const th = r() * Math.PI * 2, ph = Math.acos(2 * r() - 1), rad = 170 + r() * 140;
      pos[i * 3] = OB + rad * Math.sin(ph) * Math.cos(th);
      pos[i * 3 + 1] = 5 + rad * Math.cos(ph) * 0.7;
      pos[i * 3 + 2] = -20 + rad * Math.sin(ph) * Math.sin(th);
    }
    starGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  }
  const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({color: '#ffffff', size: 1.7, sizeAttenuation: false, fog: false, transparent: true, opacity: 0.95}));
  W.add(stars);
  // blurred star field "photo" that the glasses correct
  const blurFieldTex = ctex(768, 448, (g, w, h) => {
    g.fillStyle = '#0a1830'; g.fillRect(0, 0, w, h);
    const r = rng(89);
    const blob = (x, y, rad, a) => { const gr = g.createRadialGradient(x, y, 0, x, y, rad); gr.addColorStop(0, `rgba(215,232,255,${a})`); gr.addColorStop(1, 'rgba(160,190,235,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, rad, 0, 7); g.fill(); };
    for (let i = 0; i < 60; i++) blob(r() * w, r() * h, 6 + r() * 16, 0.25 + r() * 0.4);
    blob(390, 215, 120, 0.95); blob(390, 215, 55, 0.95); blob(180, 120, 42, 0.6); blob(610, 320, 48, 0.55);
  });
  const fieldMat = new THREE.MeshBasicMaterial({map: blurFieldTex, transparent: true, opacity: 0, fog: false});
  const field = new THREE.Mesh(new THREE.PlaneGeometry(36, 21), fieldMat);
  field.position.set(OB + 6, 3.5, -26); W.add(field);
  const lensTexShared = sharpStarTex();
  const glassesLive = makeGlasses(lensTexShared); glassesLive.position.set(OB + 1.5, -3.5, -12); glassesLive.rotation.y = -0.15; glassesLive.visible = false; W.add(glassesLive);
  const glassesTwist = makeGlasses(lensTexShared); glassesTwist.scale.setScalar(2.3); glassesTwist.position.set(OB + 14, 6.4, -24); glassesTwist.rotation.y = -0.2; glassesTwist.visible = false; W.add(glassesTwist);
  // shuttle orbiter with open bay + robot arm (spacewalk only)
  const shuttleG = new THREE.Group();
  const fus = cyl(1.5, 1.7, 11, '#e8e6df', {seg: 18}); fus.rotation.x = Math.PI / 2; shuttleG.add(fus);
  const nose = cyl(0.12, 1.5, 3.2, '#e8e6df', {seg: 18}); nose.rotation.x = Math.PI / 2; nose.position.z = 7.0; shuttleG.add(nose);
  shuttleG.add(box(7.6, 0.25, 2.8, '#d8d4c9', {y: -1.0, z: -3.4, thick: 0.03}));
  shuttleG.add(box(0.3, 2.6, 1.9, '#3a3f45', {y: 1.4, z: -5.0, thick: 0.02}));
  shuttleG.add(box(5.8, 0.25, 6.6, '#4a4f55', {y: 1.42, z: 0.2, thick: 0.02}));
  const doorL = box(2.7, 0.14, 6.6, '#cfd6dd', {thick: 0.02}); doorL.position.set(-2.5, 2.2, 0.2); doorL.rotation.z = 0.85; shuttleG.add(doorL);
  const doorR = box(2.7, 0.14, 6.6, '#cfd6dd', {thick: 0.02}); doorR.position.set(2.5, 2.2, 0.2); doorR.rotation.z = -0.85; shuttleG.add(doorR);
  shuttleG.position.set(OB - 11.5, 0.5, -15); shuttleG.rotation.y = 0.85; shuttleG.visible = false; W.add(shuttleG);
  const armG = new THREE.Group();
  armG.add(beamBetween([OB - 8.5, 2.2, -11], [OB - 5.5, 4.6, -9.5], 0.22, '#e8e6df'));
  armG.add(beamBetween([OB - 5.5, 4.6, -9.5], [OB - 2.8, 3.4, -8.8], 0.18, '#e8e6df'));
  armG.add(box(0.5, 0.5, 0.5, '#c9c3b4', {x: OB - 2.8, y: 3.4, z: -8.8, thick: 0.02}));
  armG.visible = false; W.add(armG);
  const astro = makeAstronaut(); astro.visible = false; W.add(astro);
  const miniBox = new THREE.Group();
  miniBox.add(box(0.95, 1.35, 0.95, '#7d8a8f', {thick: 0.02}));
  miniBox.add(box(1.02, 0.22, 1.02, '#c9a227', {y: 0.3, thick: 0.012}));
  miniBox.visible = false; W.add(miniBox);
  const astroA = new THREE.Vector3(OB - 6.6, 2.6, -10.6), astroB = new THREE.Vector3(OB + 0.1, 2.8, -8.9);
  const slotPos = new THREE.Vector3(OB + 1.15, 2.5, -8.35);

  // ======== WORKSHOP (build + costar) ========
  const S = LOC.shop;
  W.add(room(S, {w: 18, h: 6.5, d: 12, wall: '#cfe0da', floor: '#8a6248', seed: 43}));
  const table = new THREE.Group();
  table.add(box(3.4, 0.14, 1.7, '#6b4a36', {y: 0.98}));
  for (const [x, z] of [[-1.55, -0.7], [1.55, -0.7], [-1.55, 0.7], [1.55, 0.7]]) table.add(box(0.13, 0.95, 0.13, '#54382a', {x, y: 0.48, z}));
  table.position.set(S, 0, -1.8); W.add(table);
  W.add(box(2.6, 0.1, 1.1, '#4f5a63', {x: S, y: 1.1, z: -1.8, thick: 0.015}));
  // five pairs of coin-sized mirrors on folding arms
  const armPivots = [];
  for (let i = 0; i < 5; i++) {
    const unit = new THREE.Group(); unit.position.set(S - 1.0 + i * 0.5, 1.15, -1.8);
    unit.add(cyl(0.09, 0.11, 0.1, '#39434b', {y: 0.03, seg: 10, thick: 0.008}));
    const pivot = new THREE.Group(); pivot.position.y = 0.08; unit.add(pivot);
    pivot.add(box(0.07, 0.62, 0.07, '#8d9199', {y: 0.31, thick: 0.008}));
    pivot.add(box(0.36, 0.05, 0.05, '#8d9199', {y: 0.63, thick: 0.006}));
    for (const mx of [-0.11, 0.11]) {
      const mir = cyl(0.15, 0.15, 0.04, '#c9a227', {x: mx, y: 0.63, z: 0.02, seg: 16, thick: 0.006});
      mir.rotation.x = Math.PI / 2; pivot.add(mir);
      const face = new THREE.Mesh(new THREE.CircleGeometry(0.12, 16), new THREE.MeshBasicMaterial({color: '#fff3cf', fog: false}));
      face.position.set(mx, 0.63, 0.05); pivot.add(face);
    }
    pivot.rotation.x = 1.25;
    W.add(unit); armPivots.push(pivot);
  }
  dressShop(W, S, chars);
  const lead = character({palette: 'engineer', hat: 'bowler', glasses: true, seed: 1701}); lead.position.set(S - 1.0, 0.05, -0.5); W.add(lead); chars.push(lead);
  const engB = character({palette: 'welder', hat: 'cap', seed: 1702}); engB.position.set(S + 1.6, 0.05, -0.7); W.add(engB); chars.push(engB);
  const engC = character({palette: 'student', hat: 'none', seed: 1703}); engC.position.set(S + 0.4, 0.05, -3.9); W.add(engC); chars.push(engC);
  // the phone-booth-sized box on its dolly, with a hinged front door carrying the label
  const boxG = new THREE.Group();
  boxG.add(box(1.7, 0.18, 1.7, '#4f5a63', {y: 0.35, thick: 0.02}));
  for (const [wx, wz] of [[-0.65, -0.65], [0.65, -0.65], [-0.65, 0.65], [0.65, 0.65]]) { const wh = cyl(0.17, 0.17, 0.12, '#2b2b2e', {x: wx, y: 0.17, z: wz, seg: 12, thick: 0.01}); wh.rotation.x = Math.PI / 2; boxG.add(wh); }
  boxG.add(box(1.3, 2.5, 1.3, '#7d8a8f', {y: 1.69, thick: 0.03}));
  boxG.add(box(1.46, 0.18, 1.46, '#5f6a72', {y: 3.02, thick: 0.02}));
  boxG.add(box(0.14, 2.5, 0.14, '#5f6a72', {x: -0.66, y: 1.69, z: 0.66, thick: 0.01}), box(0.14, 2.5, 0.14, '#5f6a72', {x: 0.66, y: 1.69, z: 0.66, thick: 0.01}));
  const doorPivot = new THREE.Group(); doorPivot.position.set(-0.65, 1.69, 0.68); boxG.add(doorPivot);
  const doorPanel = box(1.3, 2.5, 0.07, '#8d979f', {x: 0.65, thick: 0.015}); doorPivot.add(doorPanel);
  const costarSign = sign('COSTAR', 1.14, 0.62, {bg: '#f2e6cc', w: 640, h: 340, font: 'bold 150px Arial, sans-serif'});
  costarSign.position.set(0.65, 0.42, 0.07); doorPivot.add(costarSign);
  const gleamMat = new THREE.MeshBasicMaterial({color: '#fff3b0', transparent: true, opacity: 0.9, depthWrite: false, fog: false});
  const gleam = new THREE.Group();
  const gs = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 6), new THREE.MeshBasicMaterial({color: '#fff3b0', fog: false})); gleam.add(gs);
  gleam.add(new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.05, 0.02), gleamMat), new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.55, 0.02), gleamMat));
  gleam.position.set(1.22, 0.78, 0.12); doorPivot.add(gleam);
  boxG.position.set(S + 4.6, 0, -2.2); W.add(boxG);
  const wk1 = character({palette: 'navy', hat: 'cap', seed: 1704}); wk1.position.set(S + 3.3, 0.05, -0.5); W.add(wk1); chars.push(wk1);
  const wk2 = character({palette: 'welder', hat: 'cap', seed: 1705}); wk2.position.set(S + 6.0, 0.05, -0.8); W.add(wk2); chars.push(wk2);

  // ======== CONTROL ROOM (galaxy) ========
  const R = LOC.screen;
  W.add(room(R, {w: 18, h: 7, d: 12, wall: '#44586b', floor: '#3f4a55', seed: 53}));
  const drawGalaxy = (sharp) => ctex(768, 442, (g, w, h) => {
    g.fillStyle = '#0a1428'; g.fillRect(0, 0, w, h);
    const r = rng(sharp ? 101 : 102);
    g.fillStyle = '#dfeaf8';
    for (let i = 0; i < 150; i++) { g.globalAlpha = 0.25 + r() * 0.75; g.beginPath(); g.arc(r() * w, r() * h, sharp ? 0.6 + r() * 1.2 : 1 + r() * 2.2, 0, 7); g.fill(); }
    g.globalAlpha = 1;
    const cx = w / 2, cy = h / 2;
    if (!sharp) {
      const blob = (x, y, rad, a) => { const gr = g.createRadialGradient(x, y, 0, x, y, rad); gr.addColorStop(0, `rgba(220,235,255,${a})`); gr.addColorStop(1, 'rgba(160,190,235,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, rad, 0, 7); g.fill(); };
      blob(cx, cy, 150, 0.85); blob(cx, cy, 70, 0.9); blob(cx - 70, cy + 26, 60, 0.4); blob(cx + 80, cy - 20, 55, 0.38);
    } else {
      // crisp spiral: two arms of star dots winding out from a bright core
      for (let arm = 0; arm < 2; arm++) {
        for (let i = 0; i < 240; i++) {
          const u = i / 240, a = arm * Math.PI + u * 4.4, rad = 12 + u * 168;
          const x = cx + Math.cos(a) * rad * 1.25 + (r() - 0.5) * (4 + u * 13);
          const y = cy + Math.sin(a) * rad * 0.62 + (r() - 0.5) * (3 + u * 8);
          g.fillStyle = r() > 0.82 ? '#ffd9a0' : (r() > 0.5 ? '#cfe2ff' : '#ffffff');
          g.globalAlpha = 0.5 + r() * 0.5;
          g.beginPath(); g.arc(x, y, 0.7 + r() * 1.5, 0, 7); g.fill();
        }
      }
      g.globalAlpha = 1;
      const core = g.createRadialGradient(cx, cy, 0, cx, cy, 42);
      core.addColorStop(0, 'rgba(255,246,220,1)'); core.addColorStop(0.4, 'rgba(255,230,180,0.55)'); core.addColorStop(1, 'rgba(255,230,180,0)');
      g.fillStyle = core; g.beginPath(); g.arc(cx, cy, 42, 0, 7); g.fill();
      g.fillStyle = '#fff8e8'; g.beginPath(); g.arc(cx, cy, 7, 0, 7); g.fill();
    }
  });
  W.add(box(9.7, 5.9, 0.3, '#141a21', {x: R, y: 3.3, z: -5.25, thick: 0.03}));
  const smudge = new THREE.Mesh(new THREE.PlaneGeometry(9.0, 5.2), new THREE.MeshBasicMaterial({map: drawGalaxy(false), fog: false}));
  smudge.position.set(R, 3.3, -5.05); W.add(smudge);
  const sharpMat = new THREE.MeshBasicMaterial({map: drawGalaxy(true), transparent: true, opacity: 0, fog: false});
  const sharpScr = new THREE.Mesh(new THREE.PlaneGeometry(9.0, 5.2), sharpMat);
  sharpScr.position.set(R, 3.3, -4.98); W.add(sharpScr);
  const dateSign = sign('JANUARY 13, 1994', 6.4, 0.95, {bg: '#f2e6cc', w: 1400, h: 200, font: 'bold 118px Arial, sans-serif'});
  dateSign.position.set(R, 6.62, -5.1); W.add(dateSign);
  dressScreen(W, R, chars);
  const pres1 = character({palette: 'official', hat: 'top', seed: 1801}); pres1.position.set(R - 3.6, 0.05, -2.4); W.add(pres1); chars.push(pres1);
  const pres2 = character({palette: 'clerk', hat: 'none', glasses: true, seed: 1802}); pres2.position.set(R + 3.6, 0.05, -2.2); W.add(pres2); chars.push(pres2);

  // ======== per-frame update ========
  let isWrong = false;
  const handOff = new THREE.Vector3(), handB = astroB.clone().add(new THREE.Vector3(0.55, 0.55, 0.45));
  const update = (t, cam, shot) => {
    for (const c of chars) c.userData.update(t, cam.position);
    traffic(t, cam);
    // hook: the shuttle climbs on "launched", smoke boils at the pad
    const rise = ease(t, wordT('hook', 4), wordT('hook', 13.5));
    shuttle.position.y = 1.2 + 26 * rise;
    shuttle.position.x = PD + 0.8 + 3.5 * rise;
    const flame = shuttle.userData.flame;
    flame.visible = t > wordT('hook', 3.4) && t < wordT('hook', 14);
    flame.scale.set(1, 0.8 + Math.sin(t * 31) * 0.25 + rise * 0.6, 1);
    const smokeA = ease(t, wordT('hook', 3.8), wordT('hook', 6)) * (1 - ease(t, wordT('hook', 9), wordT('hook', 13.5)));
    smokeMat.opacity = 0.55 * smokeA;
    smokes.forEach((s, i) => {
      const sp = 1 + 3.2 * ease(t, wordT('hook', 3.8), wordT('hook', 12)) * (0.7 + (i % 4) * 0.12);
      s.scale.set(sp, sp * 0.62, sp);
      s.position.x += s.userData.dir[0] * 0.006 * smokeA;
    });
    // hook: the first picture blooms blurry on "blurry"
    scrBlurMat.opacity = ease(t, wordT('hook', 16.5), wordT('hook', 18.6));
    // mirror: the light sweep crosses during mirror+rim; the reflection warps on "wrong shape"
    const sweepU = Math.min(1, Math.max(0, (t - wordT('mirror', 1)) / (wordT('rim', 17) - wordT('mirror', 1))));
    sweep.position.x = H - 3.1 + 6.2 * sweepU;
    const wrong = t > wordT('mirror', 15);
    if (wrong !== isWrong) { isWrong = wrong; discTopMat.map = wrong ? reflWrong : reflGood; discTopMat.needsUpdate = true; }
    // rim: the red sliver under the straightedge fades in on "too flat"
    gapMat.opacity = 0.9 * ease(t, wordT('rim', 11), wordT('rim', 13));
    // public: the third reader points and laughs on "punchline"
    if (shot === 'public') {
      const lp = ease(t, wordT('public', 11.5), wordT('public', 13));
      laugher.userData.armR.rotation.z = 2.25 * lp;
      laugher.userData.armL.rotation.z = -0.4 * lp;
      reader1.userData.armR.rotation.z = 0.25 * Math.sin(t * 1.7);
    }
    // tester: the lens slides out of place; the check lights on "passed"
    lensG.position.y = 1.95 + 0.17 * ease(t, wordT('tester', 9), wordT('tester', 11.5));
    laserMat.opacity = 0.6 + 0.3 * Math.sin(t * 9);
    const chk = ease(t, wordT('tester', 13.6), wordT('tester', 14.6));
    checkG.visible = chk > 0.01;
    checkG.scale.setScalar(Math.max(0.001, chk));
    // orbit: the telescope drifts away — too far to bring home
    hubble.position.x = OB + 2.2 * ease(t, wordT('orbit', 5), wordT('orbit', 15));
    hubble.rotation.y = shot === 'twist' ? 0.5 + (t - wordT('twist', 0)) * 0.03 : 0.5;
    // glasses: the blurred field fades in, then the glasses rise and the lenses hold sharp stars
    field.visible = shot === 'glasses';
    fieldMat.opacity = ease(t, wordT('glasses', 0), wordT('glasses', 2.5));
    glassesLive.visible = shot === 'glasses';
    if (shot === 'glasses') {
      const ge = ease(t, wordT('glasses', 10.5), wordT('glasses', 14.5));
      glassesLive.position.set(OB + 1.5 + 2.1 * ge, -3.5 + 6.3 * ge, -12 - 1.5 * ge);
      glassesLive.rotation.z = 0.06 * Math.sin(t * 1.4);
    }
    // spacewalk: shuttle, arm and astronaut exist only for this shot
    const sw = shot === 'spacewalk';
    shuttleG.visible = sw; armG.visible = sw; astro.visible = sw; miniBox.visible = sw;
    if (sw) {
      const fit = ease(t, wordT('spacewalk', 4), wordT('spacewalk', 9));
      astro.position.lerpVectors(astroA, astroB, fit);
      astro.position.y += Math.sin(t * 0.9) * 0.08;
      astro.rotation.z = Math.sin(t * 1.3) * 0.05;
      astro.getWorldPosition(handOff); handOff.x += 0.55; handOff.y += 0.55; handOff.z += 0.45;
      const insert = ease(t, wordT('spacewalk', 9), wordT('spacewalk', 11.5));
      if (insert <= 0) miniBox.position.copy(handOff);
      else miniBox.position.lerpVectors(handB, slotPos, insert);
      miniBox.rotation.y = 0.4 * (1 - insert);
    }
    // build: the five mirror-pair arms unfold one by one on "five pairs"
    armPivots.forEach((p, i) => {
      const a = ease(t, wordT('build', 5 + i * 0.8), wordT('build', 5 + i * 0.8) + 0.7);
      p.rotation.x = 1.25 - 1.5 * a;
      p.rotation.z = (i - 2) * 0.17 * a;
    });
    // costar: the door swings shut as the mirrors are "packed", gleam on the name
    doorPivot.rotation.y = -1.85 * (1 - ease(t, wordT('costar', 1), wordT('costar', 6)));
    gleam.scale.setScalar(shot === 'costar' ? 0.7 + 0.5 * ease(t, wordT('costar', 7), wordT('costar', 8)) * (0.8 + 0.2 * Math.sin(t * 6)) : 0.7);
    // galaxy: the smudge resolves into a perfect spiral on "perfect spiral"
    const rev = ease(t, wordT('galaxy', 11.6), wordT('galaxy', 13.2));
    sharpMat.opacity = rev;
    sharpScr.scale.setScalar(0.985 + 0.015 * rev);
    // twist: the glasses silhouette slides in behind the telescope on "glasses"
    glassesTwist.visible = shot === 'twist';
    if (shot === 'twist') {
      const te = ease(t, wordT('twist', 10.5), wordT('twist', 12.5));
      glassesTwist.position.x = OB + 14 - 6.5 * te;
    }
  };

  return {group: W, update};
}
