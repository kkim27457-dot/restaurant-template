import * as THREE from 'three';
import {rng, box, crate, cyl, sign, toon, ink, lampPost} from './kit.js';
import {character} from './char.js';
import * as P from './props.js';

const SHOPS = ['DINER', 'PHARMACY', 'BAKERY', 'HOTEL', 'BOOKS', 'DELI', 'SHOES', 'RADIO', 'CAFE', 'HARDWARE', 'FLOWERS', 'BARBER', 'GROCERY', 'TAILOR'];
const SHOPCOL = ['#c98f6b', '#b8775e', '#d1a47a', '#a86f5c', '#c4a27c', '#9e7b66'];
const CARCOL = ['#c43d32', '#2f6db3', '#4f8a4a', '#e6d9b8', '#7a4f73', '#3a3a3f', '#d9a441', '#9fc0d4'];

// ---------- street dressing (1990 street for the "public" shot) ----------
export function dressStreet(W, ox, {lit = false, seed = 1, chars, avoid = []} = {}) {
  const r = rng(seed);
  const near = (x) => avoid.some((a) => Math.abs(x - a) < 4.5);
  // shop fronts on the ground floor of the street facades
  let si = seed;
  for (let i = 0; i < 7; i++) for (const side of [-1, 1]) {
    const x = ox + side * (18 + i * 12.5);
    const s = P.shopFront(SHOPS[si++ % SHOPS.length], SHOPCOL[(i + 3) % 6], si); s.position.set(x, 0, 3.75); W.add(s);
  }
  for (let i = -6; i < 7; i++) { const s = P.shopFront(SHOPS[si++ % SHOPS.length], SHOPCOL[(i + 9) % 6], si); s.position.set(ox + i * 13, 0, 21.2); s.rotation.y = Math.PI; W.add(s); }
  // trees, hydrants, bins, mailboxes, news boxes, benches along both sidewalks
  for (let i = -5; i <= 5; i++) {
    const x = ox + i * 11 + 9.5;
    if (!near(x)) W.add(P.at(P.tree(1.1, seed + i), x, 0.25, 7.0));
    W.add(P.at(P.tree(1.0, seed + 40 + i), ox + i * 11 + 2, 0.25, 17.2));
    const k = i % 4, sx = ox + i * 11 + 6.6;
    if (near(sx)) continue;
    const item = [P.hydrant(), P.trashCan(), P.mailbox(), P.newsBox(['#c43d32', '#2f6db3', '#4f8a4a'][Math.abs(i) % 3])][(k + 4) % 4];
    W.add(P.at(item, sx, 0.25, 7.1));
    if (i % 3 === 0) W.add(P.at(P.bench(), ox + i * 11 + 0.5, 0.25, 4.3, 0));
  }
  W.add(P.at(P.trafficLight(), ox - 13.5, 0.25, 7.3), P.at(P.trafficLight(), ox + 13.5, 0.25, 7.3));
  // parked cars by the near curb
  for (let i = -5; i <= 5; i++) { if (i % 2) continue; const x = ox + i * 10 + 3; if (near(x)) continue; W.add(P.at(P.car(CARCOL[Math.floor(r() * 8)], {seed: i, lights: lit}), x, 0, 8.6)); }
  // pedestrians on both sidewalks
  const crowdN = lit ? 8 : 22;
  for (const a of avoid.slice(0, 1)) for (const [dx, pal, hat] of [[-2.6, 'red', 'none'], [2.8, 'teal', 'cap']]) { const c = character({palette: pal, hat, seed: seed * 7 + dx * 10}); c.position.set(a + dx, 0.25, 4.6); W.add(c); chars.push(c); }
  const cg = new THREE.Group(); W.add(cg);
  for (let i = 0; i < crowdN; i++) {
    const x = ox - 70 + r() * 140; if (near(x)) continue;
    const c = character({palette: ['engineer', 'student', 'clerk', 'official', 'red', 'teal', 'mustard', 'pink', 'navy'][Math.floor(r() * 9)], hat: ['none', 'cap', 'bowler', 'top', 'none'][Math.floor(r() * 5)], glasses: r() > 0.7, seed: seed * 50 + i});
    c.position.set(x, 0.25, r() > 0.5 ? 4.6 + r() * 1.2 : 18.0 + r() * 1.4); cg.add(c); chars.push(c);
  }
  // moving traffic in two lanes
  const traffic = [];
  for (let lane = 0; lane < 2; lane++) for (let i = 0; i < 7; i++) {
    const taxi = r() > 0.5;
    const c = i === 3 && lane === 1 ? P.bus() : P.car(CARCOL[Math.floor(r() * 8)], {taxi, lights: lit, seed: i});
    c.rotation.y = lane ? Math.PI : 0;
    const x0 = -120 + i * 34 + r() * 10, sp = (lane ? -1 : 1) * (6 + r() * 3);
    traffic.push({c, x0, sp, z: lane ? 13.8 : 10.3});
    W.add(c);
  }
  return (t, cam) => {
    for (const q of traffic) {
      let x = ((q.x0 + q.sp * t + 120) % 240 + 240) % 240 - 120;
      q.c.position.set(ox + x, 0, q.z);
      // keep cars from driving through the camera when it sits on the road
      const inRoad = cam.position.z > 7.6 && cam.position.z < 16.6 && Math.abs(cam.position.x - (ox + x)) < 140;
      q.c.visible = !(inRoad && Math.abs(cam.position.x - (ox + x)) < 7 && Math.abs(cam.position.z - q.z) < 6);
    }
  };
}

// plaza in front of the street facades (background life for the public shot)
export function dressPlaza(W, ox, chars) {
  for (const s of [-1, 1]) {
    W.add(P.at(P.tree(1.4, 70 + s), ox + s * 8.5, 0.05, -11));
    W.add(P.at(P.tree(1.3, 72 + s), ox + s * 12, 0.05, -20));
    W.add(P.at(P.bench(), ox + s * 6, 0.05, -14, s * 0.3));
    for (let i = 0; i < 3; i++) W.add(P.at(P.flag(['#c43d32', '#2f6db3', '#f2f0e6'][i]), ox + s * (6 + i * 1.6), 0.05, -9.2));
  }
  const r = rng(91);
  for (let i = 0; i < 9; i++) {
    const c = character({palette: ['red', 'teal', 'mustard', 'clerk', 'navy', 'pink', 'student'][i % 7], hat: ['none', 'bowler', 'cap', 'top'][i % 4], seed: 900 + i});
    c.position.set(ox - 10 + r() * 20, 0.05, -13 - r() * 12); W.add(c); chars.push(c);
  }
}

// hanging lamp pair used by the interiors (cord, shade, warm bulb)
function hangLamps(W, xs, z, ceilY = 6.4) {
  for (const x of xs) {
    W.add(cyl(0.02, 0.02, ceilY - 5.2, '#2b2b2e', {x, y: (ceilY + 5.2) / 2 + 0.55, z, seg: 6, thick: 0.004}));
    W.add(cyl(0.16, 0.5, 0.4, '#2f5d62', {x, y: 5.2, z, seg: 14}));
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 8), new THREE.MeshBasicMaterial({color: '#fff1c0'}));
    b.position.set(x, 5.05, z); W.add(b);
  }
}

// ---------- mirror hall ----------
export function dressHall(W, H, chars) {
  // parts shelves + cabinets along the back wall
  W.add(P.at(P.bookshelf(14), H - 7.6, 0.05, -6.55), P.at(P.bookshelf(15), H - 5.0, 0.05, -6.55));
  W.add(P.at(P.filingCabinet(), H + 6.6, 0.05, -6.4), P.at(P.filingCabinet('#8f7d6a'), H + 7.5, 0.05, -6.4));
  W.add(P.at(P.bookshelf(16, 2.0, 2.4), H - 9.75, 0.05, -1.5, Math.PI / 2));
  // a second, smaller mirror blank waiting on its stand + glass crates
  const blank = cyl(1.5, 1.5, 0.35, '#aebfca', {x: H + 6.9, y: 1.25, z: 1.8, seg: 28, thick: 0.03}); W.add(blank);
  W.add(box(2.6, 0.8, 2.6, '#5a4632', {x: H + 6.9, y: 0.4, z: 1.8, thick: 0.03}));
  W.add(crate('GLASS', {x: H - 7.8, y: 0.6, z: 2.6, ry: 0.2, color: '#8fa3ad'}));
  W.add(crate('OPTICS', {x: H - 6.4, y: 0.6, z: 3.4, ry: -0.3, color: '#a8b6a0'}));
  W.add(P.at(P.barrel('#2f6db3'), H + 8.6, 0.05, -4.2), P.at(P.barrel('#d9a441'), H + 7.7, 0.05, -5.2));
  W.add(P.at(P.ladder(3.4), H + 8.9, 0.05, -0.5));
  W.add(P.at(P.wallClock(), H - 3.4, 5.6, -6.9));
  hangLamps(W, [H - 4, H + 0.5, H + 5], -1.5, 8);
  // a technician checking a chart at the side bench
  const bench = P.desk(2.4, '#7a4f33'); bench.position.set(H - 6.2, 0.05, 3.4); bench.rotation.y = 0.15; W.add(bench);
  W.add(P.at(P.papers(6, 41), H - 6.4, 1.0, 3.3), P.at(P.deskLamp(), H - 5.4, 1.0, 3.6), P.at(P.mug('#2f6db3'), H - 6.9, 1.0, 3.8));
  const tech = character({palette: 'teal', hat: 'cap', glasses: true, seed: 1411}); tech.position.set(H - 5.6, 0.05, 4.6); W.add(tech); chars.push(tech);
  const tech2 = character({palette: 'mustard', hat: 'none', seed: 1412}); tech2.position.set(H + 5.9, 0.05, 3.4); W.add(tech2); chars.push(tech2);
}

// ---------- test lab ----------
export function dressLab(W, L, chars) {
  // operator desk with a plain graph monitor (no text), papers, phone
  const d1 = P.desk(2.4); d1.position.set(L - 3.2, 0.05, 2.6); d1.rotation.y = -0.12; W.add(d1);
  W.add(P.at(P.papers(6, 51), L - 3.6, 1.0, 2.5), P.at(P.phone(), L - 2.6, 1.0, 2.8), P.at(P.mug('#c43d32'), L - 4.1, 1.0, 2.9));
  // shelves of lens cells and instrument boxes
  W.add(P.at(P.bookshelf(24), L - 6.4, 0.05, -5.6), P.at(P.bookshelf(25), L - 3.8, 0.05, -5.6));
  W.add(P.at(P.filingCabinet('#5f7a86'), L + 7.4, 0.05, -5.4), P.at(P.filingCabinet(), L + 6.5, 0.05, -5.4));
  for (let i = 0; i < 4; i++) W.add(cyl(0.22, 0.22, 0.5, '#8d9299', {x: L + 5.2 + (i % 2) * 0.6, y: 0.25 + Math.floor(i / 2) * 0.55, z: -5.2, seg: 12, thick: 0.01}));
  // cable coils + a spare optical bench on the right
  for (const [x, z] of [[L - 7.6, 0.8], [L - 7.0, 1.6]]) {
    const coil = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.11, 8, 20), toon('#3a3f45'));
    coil.rotation.x = Math.PI / 2; coil.position.set(x, 0.12, z); ink(coil, 0.015, false); W.add(coil);
  }
  const ob = P.desk(2.0, '#4f5a63'); ob.position.set(L + 6.4, 0.05, 1.6); ob.rotation.y = 0.3; W.add(ob);
  W.add(cyl(0.3, 0.36, 0.25, '#c8cfd6', {x: L + 6.2, y: 1.13, z: 1.5, seg: 16, thick: 0.01}), cyl(0.18, 0.18, 0.3, '#9fb6c4', {x: L + 6.9, y: 1.16, z: 1.9, seg: 12, thick: 0.01}));
  W.add(P.at(P.toolbox(), L + 1.8, 0.05, 3.4), P.at(P.barrel('#5f7a86'), L - 8.2, 0.05, -3.4));
  hangLamps(W, [L - 2, L + 3], -1.5, 6);
}

// ---------- workshop ----------
export function dressShop(W, S, chars) {
  W.add(P.at(P.toolRack(3), S - 8.6, 0, -5.55), P.at(P.toolRack(4), S + 8.6, 0, -5.55));
  W.add(P.at(P.bookshelf(34), S - 5.2, 0.05, -5.6), P.at(P.bookshelf(35), S + 1.8, 0.05, -5.6));
  // side benches with work in progress
  const b1 = P.desk(2.4, '#7a4f33'); b1.position.set(S - 6.4, 0.05, 1.8); b1.rotation.y = 0.35; W.add(b1);
  W.add(P.at(P.toolbox(), S - 6.8, 1.0, 1.6), P.at(P.papers(5, 61), S - 6.1, 1.0, 2.0), cyl(0.16, 0.16, 0.06, '#e8edf1', {x: S - 5.7, y: 1.03, z: 1.5, seg: 14, thick: 0.006}));
  const b2 = P.desk(2.2, '#6b4430'); b2.position.set(S + 7.6, 0.05, 2.6); b2.rotation.y = -0.5; W.add(b2);
  W.add(P.at(P.deskLamp(), S + 7.9, 1.0, 2.4), P.at(P.mug(), S + 7.2, 1.0, 2.9));
  W.add(P.at(P.beamStack(3, 4), S - 7.6, 0.05, -3.4, 0.1), P.at(P.ladder(3.2), S + 9.2, 0.05, -2.6));
  W.add(crate('MIRRORS', {x: S - 3.4, y: 0.6, z: -5.2, ry: 0.15, color: '#9a8a7a'}));
  W.add(crate('MIRRORS', {x: S - 3.4, y: 1.8, z: -5.2, ry: -0.1, color: '#9a8a7a'}));
  W.add(P.at(P.barrel('#c43d32'), S + 8.8, 0.05, -4.4), P.at(P.barrel('#2f6db3'), S + 7.9, 0.05, -5.0), P.at(P.cone(), S - 8.8, 0.05, 4.2), P.at(P.cone(), S + 3.2, 0.05, 4.6));
  hangLamps(W, [S - 3.5, S + 1.5, S + 6], -1.2, 6.5);
  const eng = character({palette: 'welder', hat: 'cap', seed: 1611}); eng.position.set(S - 6.0, 0.05, 3.1); W.add(eng); chars.push(eng);
  const eng2 = character({palette: 'clerk', hat: 'none', glasses: true, seed: 1612}); eng2.position.set(S + 7.0, 0.05, 3.9); W.add(eng2); chars.push(eng2);
}

// ---------- control room ----------
export function dressScreen(W, R, chars) {
  // two console desks facing the screen, chairs, paper and mugs
  for (const dx of [-2.6, 2.6]) {
    const d = P.desk(2.6, '#4f5a63'); d.position.set(R + dx, 0.05, 1.4); W.add(d);
    W.add(P.at(P.chair('#33414e'), R + dx - 0.5, 0.05, 2.6, Math.PI), P.at(P.chair('#33414e'), R + dx + 0.7, 0.05, 2.6, Math.PI));
    W.add(P.at(P.papers(5, 71 + dx), R + dx - 0.6, 1.0, 1.3), P.at(P.mug('#2f6db3'), R + dx + 0.8, 1.0, 1.5), P.at(P.phone(), R + dx + 0.2, 1.0, 1.1));
    W.add(box(0.85, 0.6, 0.08, '#20262e', {x: R + dx - 0.1, y: 1.45, z: 0.95, thick: 0.01}));
    W.add(box(0.7, 0.45, 0.03, '#7fd4a8', {x: R + dx - 0.1, y: 1.45, z: 1.0, thick: 0.004, edges: false}));
  }
  W.add(P.at(P.filingCabinet('#5f7a86'), R - 7.6, 0.05, -4.6), P.at(P.filingCabinet(), R - 6.7, 0.05, -4.6));
  W.add(P.at(P.bookshelf(44), R + 7.9, 0.05, -3.4, -Math.PI / 2));
  W.add(P.at(P.wallClock(), R - 5.4, 5.2, -5.9));
  hangLamps(W, [R - 3, R + 3], 0.5, 7);
  const tech = character({palette: 'mustard', hat: 'cap', seed: 1711}); tech.position.set(R - 4.4, 0.05, 3.4); W.add(tech); chars.push(tech);
  const tech2 = character({palette: 'teal', hat: 'none', seed: 1712}); tech2.position.set(R + 4.6, 0.05, 3.2); W.add(tech2); chars.push(tech2);
}
