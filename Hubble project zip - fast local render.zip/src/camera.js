import * as THREE from 'three';
import timing from './timing.json';

// monotone cubic time warp: beat times per path key -> path position 0..1 (ease in/out)
export function warpU(T, t) {
  const n = T.length; if (t <= T[0]) return 0; if (t >= T[n - 1]) return 1;
  const sec = []; for (let i = 0; i < n - 1; i++) sec.push((1 / (n - 1)) / (T[i + 1] - T[i]));
  const m = [0]; for (let i = 1; i < n - 1; i++) m.push(2 * sec[i - 1] * sec[i] / (sec[i - 1] + sec[i])); m.push(0);
  let i = 0; while (t > T[i + 1]) i++;
  const h = T[i + 1] - T[i], x = (t - T[i]) / h, x2 = x * x, x3 = x2 * x;
  return (2 * x3 - 3 * x2 + 1) * (i / (n - 1)) + (x3 - 2 * x2 + x) * h * m[i] + (-2 * x3 + 3 * x2) * ((i + 1) / (n - 1)) + (x3 - x2) * h * m[i + 1];
}

const S = Object.fromEntries(timing.shots.map((s) => [s.key, s]));
const keys = timing.shots.map((s) => s.key);
// cut = midway between the end of one sentence and the start of the next
export const CUTS = keys.map((k, i) => (i === 0 ? 0 : (timing.shots[i - 1].end + timing.shots[i].start) / 2));
export const END = timing.duration;
// word time: proportional position of word index (0-based) inside a sentence
export const wordT = (key, idx) => S[key].start + (S[key].end - S[key].start) * idx / S[key].words;

// light presets
export const LIGHTS = {
  night: {sun: '#a9b8ff', si: 1.0, sky: '#4a50a0', gnd: '#2a2030', hi: 1.0, fog: '#232856', near: 120, far: 420, sunOff: [-40, 90, 50], shadow: 70, top: '#0b1030', hor: '#3e3f86', pt: null},
  day: {sun: '#fff0cf', si: 2.6, sky: '#a9d8ff', gnd: '#d9a878', hi: 1.15, fog: '#cfe7f7', near: 160, far: 650, sunOff: [-50, 90, 60], shadow: 80, top: '#3d8fe0', hor: '#cde9f8', pt: null},
  storm: {sun: '#cdd3de', si: 1.1, sky: '#8a95a6', gnd: '#4a4f58', hi: 1.0, fog: '#66738a', near: 45, far: 260, sunOff: [-40, 80, 40], shadow: 80, top: '#3c4454', hor: '#7d889a', pt: null},
  office: {sun: '#fff4e4', si: 1.6, sky: '#f4fbff', gnd: '#b48a62', hi: 1.05, fog: '#efe2cb', near: 30, far: 90, sunOff: [-6, 9, 7], shadow: 10, top: '#7fb7e6', hor: '#d6ecf6', pt: {c: '#ffc77a', i: 7, p: [-2.5, 3.6, 0.5], d: 14}},
  yard: {sun: '#ffe7bd', si: 2.5, sky: '#b5dcff', gnd: '#d1ad7c', hi: 1.15, fog: '#e2e3d4', near: 70, far: 260, sunOff: [-14, 22, 14], shadow: 20, top: '#3d8fe0', hor: '#d9ecf5', pt: null},
  joint: {sun: '#ffe0b0', si: 2.3, sky: '#c4c8dc', gnd: '#5a5662', hi: 1.3, fog: '#4a4a58', near: 30, far: 80, sunOff: [-7, 12, 9], shadow: 12, top: '#222', hor: '#333', pt: {c: '#ffb066', i: 16, p: [-3.2, 4.6, -1.5], d: 12}},
  weather: {sun: '#eef2ff', si: 1.4, sky: '#eef3f6', gnd: '#8f7b66', hi: 1.1, fog: '#e3e7e1', near: 30, far: 90, sunOff: [-6, 9, 7], shadow: 10, top: '#56606e', hor: '#9aa4b0', pt: {c: '#ffd58a', i: 5, p: [0, 3.8, 0], d: 14}},
  morning: {sun: '#ffbf7a', si: 2.5, sky: '#ffe0bd', gnd: '#c08a5a', hi: 1.0, fog: '#f6d9b8', near: 160, far: 650, sunOff: [-60, 40, 50], shadow: 80, top: '#6fa6dd', hor: '#ffd3a1', pt: null},
  // presets for this story
  hall: {sun: '#fff3da', si: 2.2, sky: '#eaf6ff', gnd: '#b8a888', hi: 1.15, fog: '#e8f0f2', near: 40, far: 150, sunOff: [-8, 12, 7], shadow: 14, top: '#7fb7e6', hor: '#d6ecf6', pt: {c: '#ffd9a0', i: 6, p: [0, 5.2, -1], d: 20}},
  lab: {sun: '#cfe4de', si: 1.1, sky: '#5a7a86', gnd: '#3a3630', hi: 0.95, fog: '#2e3c42', near: 25, far: 90, sunOff: [-5, 8, 6], shadow: 12, top: '#22303a', hor: '#3c545e', pt: {c: '#ffb066', i: 10, p: [1.5, 3.4, -1], d: 13}},
  space: {sun: '#fff2cf', si: 2.7, sky: '#a9d8ff', gnd: '#5a6a86', hi: 1.0, fog: '#0e2c52', near: 250, far: 900, sunOff: [-40, 60, 50], shadow: 26, top: '#14467e', hor: '#6ea8dd', pt: null},
  gold: {sun: '#ffc478', si: 2.6, sky: '#ffd9a8', gnd: '#6a5a4a', hi: 1.0, fog: '#3a2c33', near: 250, far: 900, sunOff: [-55, 26, 45], shadow: 26, top: '#2c4a7a', hor: '#ff9e5e', pt: null},
  shop: {sun: '#fff1d6', si: 1.9, sky: '#eef7f2', gnd: '#a87c58', hi: 1.1, fog: '#e6ddc8', near: 35, far: 110, sunOff: [-7, 10, 6], shadow: 13, top: '#7fb7e6', hor: '#dcefe8', pt: {c: '#ffc77a', i: 7, p: [0, 4.4, -1], d: 16}},
  screen: {sun: '#bcd2e8', si: 1.0, sky: '#7286a0', gnd: '#2f3844', hi: 0.95, fog: '#33404e', near: 30, far: 100, sunOff: [-6, 9, 6], shadow: 13, top: '#1d2733', hor: '#41546a', pt: {c: '#9fd8ff', i: 9, p: [0, 3.4, -3.2], d: 15}},
};

const v = (a) => new THREE.Vector3(...a);
// camera plan: per shot, location light, anchor (for the light), path keys {p, l}, optional beat times
export const PLAN = {
  // launch pad at dawn: crane up with the shuttle, then swing to the photo screen as the star blooms blurry
  hook: {light: 'morning', anchor: [0, 10, -6], keys: [{p: [7.5, 2.0, 10], l: [0, 7, -8]}, {p: [6.0, 9.5, 7], l: [-0.5, 22, -8]}, {p: [8.5, 4.2, 6.5], l: [10.5, 3.4, -2]}], beats: 'words:hook:0,9,16'},
  // mirror hall: push in to the great mirror while light sweeps it; 2.4 METERS beam above
  mirror: {light: 'hall', anchor: [300, 2, -1], keys: [{p: [294.2, 5.2, 5.8], l: [300, 1.0, -1.5]}, {p: [297.2, 2.8, 3.2], l: [300.3, 1.15, -1.6]}, {p: [299.0, 1.6, 0.6], l: [301.5, 1.1, -1.8]}], beats: 'words:mirror:0,7,14'},
  // 1990 street: two newspaper readers big in the foreground, newsstand behind them
  public: {light: 'day', anchor: [600, 1.5, 3], keys: [{p: [601.9, 1.75, 10.9], l: [601.9, 1.3, 6.9]}, {p: [601.7, 1.65, 9.9], l: [601.95, 1.35, 7.0]}, {p: [601.2, 1.8, 10.1], l: [602.3, 1.5, 6.4]}], beats: 'words:public:0,6,12'},
  // mirror hall, continuous: macro glide from the mirror's centre out to the rim and the hair
  rim: {light: 'hall', anchor: [300, 2, -1], keys: [{p: [299.0, 1.6, 0.6], l: [301.5, 1.1, -1.8]}, {p: [300.7, 1.55, 0.35], l: [302.5, 1.2, -1.05]}, {p: [301.9, 1.5, 0.3], l: [303.0, 1.22, -1.0]}], beats: 'words:rim:0,9,15'},
  // test lab: from the mirror under test, push in to the measuring machine and its offset lens
  tester: {light: 'lab', anchor: [900, 2, -1], keys: [{p: [896.5, 2.6, 4.8], l: [900, 1.6, -1.5]}, {p: [899.5, 2.1, 2.6], l: [902.3, 1.8, -1.5]}, {p: [901.2, 1.95, 0.6], l: [902.8, 1.85, -1.5]}], beats: 'words:tester:0,6,13'},
  // orbit: slow drift around the telescope with the Earth limb behind; the telescope recedes
  orbit: {light: 'space', anchor: [1200, 2, -6], keys: [{p: [1193.5, 4.5, 3.5], l: [1200, 2.5, -7]}, {p: [1196.0, 3.4, 0.5], l: [1200.5, 2.4, -7]}, {p: [1198.5, 3.0, -1.5], l: [1201, 2.2, -7]}], beats: 'words:orbit:0,5,11'},
  // orbit, continuous: end looking through the glasses at the blurred, then sharp, star field
  glasses: {light: 'space', anchor: [1200, 2, -6], keys: [{p: [1198.5, 3.0, -1.5], l: [1201, 2.2, -7]}, {p: [1199.5, 3.0, -3.5], l: [1203.5, 2.9, -16]}, {p: [1200.5, 2.9, -5.5], l: [1204, 2.8, -20]}], beats: 'words:glasses:0,7,13'},
  // workshop: lead engineer in the foreground, track to the assembly table as the arms unfold
  build: {light: 'shop', anchor: [1500, 1.5, -1], keys: [{p: [1498.8, 1.8, 2.6], l: [1499.3, 1.3, -0.9]}, {p: [1499.6, 1.7, 1.2], l: [1500.2, 1.1, -1.8]}, {p: [1500.3, 1.5, 0.2], l: [1500.1, 1.15, -1.9]}], beats: 'words:build:0,4,9'},
  // workshop, continuous: on to the phone-booth box, ending square on the COSTAR sign
  costar: {light: 'shop', anchor: [1500, 1.5, -1], keys: [{p: [1500.3, 1.5, 0.2], l: [1500.1, 1.15, -1.9]}, {p: [1502.6, 1.7, 1.4], l: [1504.4, 1.5, -2.0]}, {p: [1504.5, 1.6, 1.6], l: [1504.6, 1.7, -1.6]}], beats: 'words:costar:0,4,7'},
  // orbit: wide on the shuttle's open bay, push in as the astronaut fits the box
  spacewalk: {light: 'space', anchor: [1200, 2, -6], keys: [{p: [1188, 4.5, 2], l: [1196, 2.2, -9]}, {p: [1192.5, 3.4, -1], l: [1197.5, 2.5, -8.6]}, {p: [1195.8, 3.0, -3.4], l: [1198.8, 2.6, -8.4]}], beats: 'words:spacewalk:0,5,10'},
  // control room: slow push to the big screen between the two presenters
  galaxy: {light: 'screen', anchor: [2100, 3, -4], keys: [{p: [2100, 2.2, 5.6], l: [2100, 3.2, -5.3]}, {p: [2100, 2.4, 3.4], l: [2100, 3.4, -5.3]}, {p: [2100, 2.6, 1.2], l: [2100, 3.5, -5.3]}], beats: 'words:galaxy:0,6,11'},
  // orbit at golden light: slow pull-back; sharp stars and the glasses silhouette
  twist: {light: 'gold', anchor: [1200, 2, -6], keys: [{p: [1197.5, 3.2, -0.5], l: [1200.5, 2.6, -7]}, {p: [1194.0, 4.5, 3.0], l: [1201, 2.8, -8]}, {p: [1189.0, 6.0, 8.0], l: [1202, 3.0, -10]}], beats: 'words:twist:0,5,11'},
};

// precompute curves + beat times
const CURVES = {};
keys.forEach((k, i) => {
  const P = PLAN[k];
  const a = CUTS[i], b = i + 1 < keys.length ? CUTS[i + 1] : END;
  let T;
  if (P.beats && P.beats.startsWith('words:')) {
    const [, key, idx] = P.beats.split(':');
    T = idx.split(',').map(Number).map((n) => wordT(key, n));
    T[0] = a; T[T.length - 1] = b;
  } else T = P.keys.map((_, j) => a + (b - a) * j / (P.keys.length - 1));
  CURVES[k] = {
    p: new THREE.CatmullRomCurve3(P.keys.map((q) => v(q.p)), false, 'centripetal'),
    l: new THREE.CatmullRomCurve3(P.keys.map((q) => v(q.l)), false, 'centripetal'),
    T, a, b,
  };
});

export function shotAt(t) {
  let i = 0; while (i + 1 < CUTS.length && t >= CUTS[i + 1]) i++;
  return keys[i];
}
export function cameraAt(t) {
  const k = shotAt(t); const C = CURVES[k];
  const u = warpU(C.T, t);
  return {key: k, pos: C.p.getPointAt(u), look: C.l.getPointAt(u), plan: PLAN[k], a: C.a, b: C.b};
}
// dip-to-cream opacity around location changes (0.4 s total)
const CONT = new Set(['rim', 'glasses', 'costar']); // same-location continuations: mirror->rim, orbit->glasses, build->costar
export function dipAt(t) {
  let o = 0;
  keys.forEach((k, i) => {
    if (i === 0 || CONT.has(k)) return;
    const c = CUTS[i]; const d = Math.abs(t - c);
    if (d < 0.2) o = Math.max(o, 1 - d / 0.2);
  });
  return o;
}
