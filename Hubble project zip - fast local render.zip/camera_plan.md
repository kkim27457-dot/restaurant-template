# Camera plan (beat-synced, ease in/out) — Glasses for a Telescope
Locations (LOC x-offsets): pad 0 · mirror hall 300 · street 600 · lab 900 · orbit 1200 · workshop 1500 · control room 2100.
Orbit set hosts orbit + glasses + spacewalk + twist (shuttle/astronaut/glasses props are visibility-gated per shot).

| Shot | Time | Location | Light | Move | Subjects / in-world labels |
|---|---|---|---|---|---|
| hook | 0.15-6.50 | Launch pad, dawn | morning | Low at pad, crane up following the shuttle, swing right to the photo screen | Shuttle lifts off (words 4-10); photo screen star blooms into a blurry halo on "blurry" (17-19) |
| mirror | 6.92-11.66 | Mirror hall | hall | Push in across the hall to the great mirror | Polished disc, light sweep, "2.4 METERS" beam sign; reflection warps on "wrong shape" (15) |
| public | 12.08-16.29 | 1990 street + newsstand | day | Push in on readers, swing to the stand | Two readers with a newspaper (35-50% frame height), third points and laughs on "punchline" (12-14) |
| rim | 16.71-21.14 | Mirror hall (CONT) | hall | Macro glide centre -> rim along the surface | Straightedge + red light sliver on "too flat" (11-13); hair strand at the rim on "hair" (18) |
| tester | 21.56-25.58 | Test lab | lab | Push in from the mirror to the measuring machine | Red laser line; lens slides out of place (9-11); green check lights on "passed" (14-15) |
| orbit | 25.76-29.06 | Orbit | space | Slow drift around the telescope, Earth limb behind | Telescope recedes gently — too far to reach |
| glasses | 29.52-33.74 | Orbit (CONT) | space | Continue drift, end looking through the glasses | Blurred star field; glasses slide in (11-15), crisp stars inside the lenses |
| build | 34.14-38.36 | Workshop | shop | Start on the lead engineer, track to the assembly table | Five mirror-pair arms unfold one by one (5-10) |
| costar | 38.64-41.68 | Workshop (CONT) | shop | Continue to the big box, push into its label | Door swings shut (1-6); "COSTAR" sign fills the end frame |
| spacewalk | 41.98-47.20 | Orbit (shuttle) | space | Wide on the shuttle bay, push to the telescope flank | Astronaut rides the arm in (4-9), box slides into its slot (9-11.5) |
| galaxy | 47.74-54.04 | Control room | screen | Slow push toward the big screen between two presenters | "JANUARY 13, 1994" sign; M100 smudge crossfades to a crisp spiral on "perfect spiral" (12-13) |
| twist | 54.56-58.26 | Orbit, golden light | gold | Slow pull-back from the telescope | Sharp stars; a subtle glasses silhouette fades in on "glasses" (11-12.5) |

Dip to cream (0.4 s) at every location change; CONT (no dip): rim (after mirror), glasses (after orbit), costar (after build).
Captions are automatic from timing.json; no shot key is named "close", so captions sit at the standard 67% height and clear the signs.
